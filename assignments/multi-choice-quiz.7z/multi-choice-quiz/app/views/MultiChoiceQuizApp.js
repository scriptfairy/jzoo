define([

    // Libs
    'backbone',
    'jquery',
    'underscore',
    
    // Template
    'text!./MultiChoiceQuizApp.html'

], function(
		
		Backbone, $, _,
		template
){
	
	var MultiChoiceApp = Backbone.View.extend({
		
		template: _.template(template),
		
		initialize: function() {
			this.render();
		},
		
		render: function() {
			
			var html = this.template();
			this.$el.html(html);
		}
	
	});
	
	return MultiChoiceApp; 
	
});